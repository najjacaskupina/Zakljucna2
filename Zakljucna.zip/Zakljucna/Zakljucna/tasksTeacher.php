<!DOCTYPE html>
<html lang="en">
<head>
    <?php
    include 'server/teacherSession.php';
    ?>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tasks ~ Teacher</title>
    <link rel="icon" type="image/x-icon" href="/media/logo.png">
    <link rel="stylesheet" href="styles/tasksTeacher.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter" rel="stylesheet">
    <script>
        function showSubmissions(val){
            x = document.getElementById('submissions');
            x.style.display = "block";
            str = '<span class="x" onclick="hideSubmissions()">x</span>';
            str += "<table><tr> <th>Name of student</th> <th>Date</th> <th>Task</th> </tr><tr> <td>Teo</td> <td>11.11.1111</td> <td>Task</td> </tr><tr> <td>Teo</td> <td>11.11.1111</td> <td>Task</td> </tr></table>";
            x.innerHTML = str;
        }
        function hideSubmissions(){
            x = document.getElementById('submissions');
            x.style.display = "none";
            x.innerHTML = "";
        }
    </script>
</head>
<body>
    <div id="submissions">
        <span class="x" onclick="hideSubmissions()">x</span>
    </div>
    <div class="container">
        <aside>
            <div class="heading">
                <h3>Web classroom</h3>
            </div>
            <div class="middleSidebar">
                <ul>
                    <li onclick="window.location='homeTeacher.php'">
                        <span>My Profile</span>
                        <img class="sidebar-icon" src="media/profile.png" alt="profile">
                    </li>
                    <li class="active" onclick="window.location='tasksTeacher.php'">
                        <span>Tasks</span>
                        <img class="sidebar-icon" src="media/tasks.png" alt="profile">
                    </li>
                    <li onclick="window.location='gradesTeacher.php'">
                        <span>Grades</span>
                        <img class="sidebar-icon" src="media/grades.png" alt="profile">
                    </li>
                    <li onclick="window.location='server/logoutTeacher.php'">
                        <span>Log out</span>
                        <img class="sidebar-icon" src="media/logout.png" alt="profile">
                    </li>
                </ul>
            </div>
        </aside>
        <main>
            <h1>My tasks</h1>
            <?php 
           $sql = "select * from subjects, teachers_subjects where teachers_subjects.teacherId='$teacherId' and teachers_subjects.subjectId = subjects.subjectId";
           $resultGetTasks = mysqli_query($conn, $sql);
           while ($rowGetTask = mysqli_fetch_array($resultGetTasks)) {
               echo "<h2>".$rowGetTask['subjectName']." ".$rowGetTask['year']."</h2> <table> <tbody> <tr> <th>Task</th> <th>Date added</th> <th>Date finished</th> <th>Submissions</th> </tr>";
             $subjectId = $rowGetTask['subjectId'];

               $sql = "select * from tasks where subjectId = '$subjectId'";
               $result = mysqli_query($conn, $sql);
               while ($row = mysqli_fetch_array($result)) {
                $taskId = $row['taskId'];
                echo "<tr> <td>".$row['taskName']."</td> <td>".$row['taskStartDate']."</td> <td>".$row['taskEndDate']."</td> <td onclick=\"showSubmissions(".$row['taskId'].")\">";
                $sql2 = "SELECT COUNT(submitedTaskId) FROM submitedTasks where taskId='$taskId'";
                $result2 = mysqli_query($conn, $sql2);
                $row2 = mysqli_fetch_array($result2);
                echo $row2['COUNT(submitedTaskId)'];
                echo "</td> </tr>";
                
               }
               echo '</tbody> </table>';
               ?>

                    <form action="server/addTask.php" method="post" enctype="multipart/form-data">
                    <input type="text" name="name" placeholder="Name of task">
                    <input type="file" name="file">
                    <label for="dateFinished">Date finished:</label>
                    <input type="date" name="dateFinished">
                    <input type="hidden" name="subjectId" value="<?php echo $subjectId;?>">
                    <input type="submit" value="Add task">
                    
                </form>
                <?php
               
               
               
            }
            ?>
            
<br>
<br>
<br>
<br>
        </main>
    </div>
    <footer>
    <h2>About school</h2>
    <p>The School Center Celje is a Slovenian public education institution based in The Pot na Lavo 22 in Celje. It combines grammar schools, four secondary vocational schools, a higher vocational school and an inter-entrepreneurial education centre. It is one of the largest school centres in Slovenia. &copy; | 2022</p>
    </footer>
</body>
</html>