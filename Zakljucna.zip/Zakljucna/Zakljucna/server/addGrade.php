<?php
include 'conn.php';
session_start();
if (!isset($_SESSION['teacherToken'])) {
  header("Location: ../index.php");
}
$token = $_SESSION['teacherToken'];

$subjectId = $_POST['subjectId'];
$studentId = $_POST['studentId'];
$grade = $_POST['grade'];

$sqlGetEmail = "insert into grades (subjectId, studentId, grade) values ('$subjectId', '$studentId', '$grade')"; 
$resultGetEmail = mysqli_query($conn, $sqlGetEmail);
header("location: ../gradesTeacher.php");
?>