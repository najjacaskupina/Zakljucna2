<?php
include 'conn.php';
session_start();
if (!isset($_SESSION['teacherToken'])) {
  header("Location: ../index.php");
}
$token = $_SESSION['teacherToken'];

$t=time();
echo($t . "<br>");
$startTime = date("Y-m-d",$t);
echo $startTime;

$cypherMethod = 'AES-256-CBC';
$key = "markoVosner27";
$iv = '1234567891011121';

$name = $_POST['name'];
$dateFinished = $_POST['dateFinished'];

$subjectId = $_POST['subjectId'];
$name = mysqli_real_escape_string($conn, $name);
$dateFinished = mysqli_real_escape_string($conn, $dateFinished);


$sqlGetEmail = "insert into tasks (taskName, subjectId, taskStartDate, taskEndDate) values ('$name', '$subjectId', '$startTime', '$dateFinished')"; 
$resultGetEmail = mysqli_query($conn, $sqlGetEmail);
header("location: ../tasksTeacher.php");
?>