<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/x-icon" href="media/logo.png">
    <title>Octopussy school</title>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <link rel="stylesheet" href="https://unpkg.com/aos@next/dist/aos.css" />
    <link rel="stylesheet" href="styles/index.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter" rel="stylesheet">
</head>
<body>
    <nav data-aos="fade-in" data-aos-delay="0" data-aos-duration="900">
        
        <div class="linkBox">
            <ul>
                <li><a href="#about">About</a></li>
                <li><a href="#login">Login</a></li>
                <li><a href="#register">Register</a></li>
                <li><a href="#loginTeacher">Teacher login</a></li>
                <li><a href="#loginAdmin">admin login</a></li>
            </ul>
        </div>
    </nav>
    <main>
        <section class="aboutOctopussySchool" id="about" data-aos="fade-down" data-aos-delay="900" data-aos-duration="1200">
            <h1>about web classroom</h1>
            <p>This is a web classroom for students of School Center Celje. Join in at the bottom.</p>
            <button onclick="window.location='#login'">Log in</button>
        </section>
        <section class="secWForm" id="login" data-aos="fade-left" data-aos-delay="0" data-aos-duration="1200">
            <h1>Log in</h1>
            <form action="server/login.php" method="post">
                <input class="text" type="text" name="username" placeholder="Username...">
                <input class="text" type="password" name="password" placeholder="Password...">
                <input class="submit" type="submit" value="Log In">
            </form>
        </section>
        <section class="secWForm" id="register" data-aos="fade-right" data-aos-delay="0" data-aos-duration="1200">
            <h1>Register</h1>
            <form action="server/register.php" method="post">
                <div class="formFlex">
                    <input class="text" type="text" name="firstName" placeholder="First Name...">
                    <input class="text" type="text" name="lastName" placeholder="Last Name...">
                </div>
                <div class="formFlex">
                    <input class="text" type="text" name="username" placeholder="Username...">
                    <input class="text" type="password" name="password" placeholder="Password...">
                </div>
                <input class="submit" type="submit" value="Register">
            </form>
        </section>
        <section class="secWForm" id="loginTeacher" data-aos="fade-left" data-aos-delay="0" data-aos-duration="1200">
            <h1>Log in as teacher</h1>
            <form action="server/loginTeacher.php" method="post">
                <input class="text" type="text" name="username" placeholder="Username...">
                <input class="text" type="password" name="password" placeholder="Password...">
                <input class="submit" type="submit" value="Log In">
            </form>
        </section>
        <section class="secWForm lastSection" id="loginAdmin" data-aos="fade-right" data-aos-delay="0" data-aos-duration="1200">
            <h1>Log in as admin</h1>
            <form action="server/loginAdmin.php" method="post">
                <input class="text" type="password" name="password" placeholder="Password...">
                <input class="submit" type="submit" value="Log In">
            </form>
        </section>
    </main>
    <?php 
        include 'parts/footer.html';
        include 'aos/aosSetting.html';
    ?>
</body>
</html>