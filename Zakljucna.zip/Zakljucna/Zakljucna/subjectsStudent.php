<?php
include 'server/studentSession.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Subjects ~ Student</title>
    <link rel="icon" type="image/x-icon" href="media/logo.png">
    <link rel="stylesheet" href="styles/subjectsStudent.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter" rel="stylesheet">
    <link rel="stylesheet" href="https://unpkg.com/aos@next/dist/aos.css" />
</head>
<body>
    <div class="container">
        <aside data-aos="fade-right">
            <div class="heading">
                <h3>Web classroom</h3>
            </div>
            <div class="middleSidebar">
                <ul>
                    <li onclick="window.location='homeStudent.php'">
                        <span>My Profile</span>
                        <img class="sidebar-icon" src="media/profile.png" alt="profile">
                    </li>
                    <li class="active" onclick="window.location='subjectsStudent.php'">
                        <span>Subjects</span>
                        <img class="sidebar-icon" src="media/subjects.png" alt="profile">
                    </li>
                    <li onclick="window.location='tasksStudent.php'">
                        <span>Tasks</span>
                        <img class="sidebar-icon" src="media/tasks.png" alt="profile">
                    </li>
                    <li onclick="window.location='gradesStudent.php'">
                        <span>Grades</span>
                        <img class="sidebar-icon" src="media/grades.png" alt="profile">
                    </li>
                    <li onclick="window.location='server/logout.php'">
                        <span>Log out</span>
                        <img class="sidebar-icon" src="media/logout.png" alt="profile">
                    </li>
                </ul>
            </div>
        </aside>
        <main>
            <h1>All subjects</h1>
            <section class="subjects">
                <h2>1st grade</h2>
                <div class="container" data-aos="fade-up">
                <?php
                    $sqlCheckSubjects = "select * from subjects where year = '1'";
                    $resultCheckSubjects = mysqli_query($conn, $sqlCheckSubjects);
                    $rowCheckSubjects = mysqli_fetch_array($resultCheckSubjects);
                    if($rowCheckSubjects == null){
                        echo "<p>No classes</p>";
                    }else{
                        $sqlGetSubjects = "select * from subjects where year = '1'";
                        $resultGetSubjects = mysqli_query($conn, $sqlGetSubjects);
                        while($rowGetSubjects = mysqli_fetch_array($resultGetSubjects)){
                            $abbr = $rowGetSubjects['abbr'];
                            $subjectName = $rowGetSubjects['subjectName'];
                            $subjectId = $rowGetSubjects['subjectId'];
                            $year = "1";
                            include 'parts/subjectBoxStudent.php';
                        }
                    }
                ?>
                
                </div>
                <h2>2nd grade</h2>
                <div class="container" data-aos="fade-up">
                <?php
                    $sqlCheckSubjects = "select * from subjects where year = '2'";
                    $resultCheckSubjects = mysqli_query($conn, $sqlCheckSubjects);
                    $rowCheckSubjects = mysqli_fetch_array($resultCheckSubjects);
                    if($rowCheckSubjects == null){
                        echo "<p>No classes</p>";
                    }else{
                        $sqlGetSubjects = "select * from subjects where year = '2'";
                        $resultGetSubjects = mysqli_query($conn, $sqlGetSubjects);
                        while($rowGetSubjects = mysqli_fetch_array($resultGetSubjects)){
                            $abbr = $rowGetSubjects['abbr'];
                            $subjectName = $rowGetSubjects['subjectName'];
                            $subjectId = $rowGetSubjects['subjectId'];
                            $year = "2";
                            include 'parts/subjectBoxStudent.php';
                        }
                    }
                ?>
                </div>
                <h2>3rd grade</h2>
                <div class="container" data-aos="fade-up">
                <?php
                    $sqlCheckSubjects = "select * from subjects where year = '3'";
                    $resultCheckSubjects = mysqli_query($conn, $sqlCheckSubjects);
                    $rowCheckSubjects = mysqli_fetch_array($resultCheckSubjects);
                    if($rowCheckSubjects == null){
                        echo "<p>No classes</p>";
                    }else{
                        $sqlGetSubjects = "select * from subjects where year = '3'";
                        $resultGetSubjects = mysqli_query($conn, $sqlGetSubjects);
                        while($rowGetSubjects = mysqli_fetch_array($resultGetSubjects)){
                            $abbr = $rowGetSubjects['abbr'];
                            $subjectName = $rowGetSubjects['subjectName'];
                            $subjectId = $rowGetSubjects['subjectId'];
                            $year = "3";
                            include 'parts/subjectBoxStudent.php';
                        }
                    }
                ?>
                </div>
                <h2>4th grade</h2>
                <div class="container" data-aos="fade-up">
                <?php
                    $sqlCheckSubjects = "select * from subjects where year = '4'";
                    $resultCheckSubjects = mysqli_query($conn, $sqlCheckSubjects);
                    $rowCheckSubjects = mysqli_fetch_array($resultCheckSubjects);
                    if($rowCheckSubjects == null){
                        echo "<p>No classes</p>";
                    }else{
                        $sqlGetSubjects = "select * from subjects where year = '4'";
                        $resultGetSubjects = mysqli_query($conn, $sqlGetSubjects);
                        while($rowGetSubjects = mysqli_fetch_array($resultGetSubjects)){
                            $abbr = $rowGetSubjects['abbr'];
                            $subjectName = $rowGetSubjects['subjectName'];
                            $subjectId = $rowGetSubjects['subjectId'];
                            $year = "4";
                            include 'parts/subjectBoxStudent.php';
                        }
                    }
                ?>
                </div>
            </section>
        </main>
    </div>
    <?php 
        include 'parts/footer.html';
        include 'aos/aosSetting.html';
    ?>
</body>
</html>