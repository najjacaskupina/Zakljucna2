<?php
include 'conn.php';
session_start();
if (!isset($_SESSION['adminToken'])) {
  header("Location: ../index.php");
}
$token = $_SESSION['adminToken'];

$teacherId = $_POST['teacherId'];
$subjectId = $_POST['subjectId'];

$teacherId = mysqli_real_escape_string($conn, $teacherId);
$subjectId = mysqli_real_escape_string($conn, $subjectId);

    $sqlInsertData = "delete from teachers_subjects where teacherId = '$teacherId' and subjectId = '$subjectId'";
    mysqli_query($conn, $sqlInsertData);
    header('Location: ../admin.php');

?>