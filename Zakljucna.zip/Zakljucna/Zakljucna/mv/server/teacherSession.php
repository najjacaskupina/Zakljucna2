<?php
include 'conn.php';
session_start();
if (!isset($_SESSION['teacherToken'])) {
  header("Location: index.php");
}
$teacherToken = $_SESSION['teacherToken'];
$sqlTeachersData = "select * from teachers where token = '$teacherToken'";
$resultTeachersData = mysqli_query($conn, $sqlTeachersData);
$rowTeachersData = mysqli_fetch_array($resultTeachersData);
$teacherId = $rowTeachersData['teacherId'];
$username = $rowTeachersData['username'];
$firstName = $rowTeachersData['teacherFirstName'];
$lastName = $rowTeachersData['teacherLastName'];
/*
echo "token €tokenid = id uporabnika+čas v unix <br>";
echo "token trenutne seje: €token = openssl_encrypt(€tokenId, €cypherMethod, €key, €options=0, €iv); <br></blockquote>";
echo $token;
*/
?>