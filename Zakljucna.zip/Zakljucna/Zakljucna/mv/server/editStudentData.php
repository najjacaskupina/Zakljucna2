<?php
include 'conn.php';
include 'adminSession.php';

$studentId = $_POST['studentId'];

$firstName = $_POST['studentFirstNameEdit'];
$lastName = $_POST['studentLastNameEdit'];
$username = $_POST['studentUsernameEdit'];
$password = $_POST['studentPasswordEdit'];

$firstName = mysqli_real_escape_string($conn, $firstName);
$lastName = mysqli_real_escape_string($conn, $lastName);
$username = mysqli_real_escape_string($conn, $username);
$password = mysqli_real_escape_string($conn, $password);

$sqlValidateAdmin = "select * from admin where token = '$token'";
$resultValidateAdmin = mysqli_query($conn, $sqlValidateAdmin);
if(!mysqli_num_rows($resultValidateAdmin)>=1){
    exit("Wrong token");
}else{
    if($password != ""){
        $password = password_hash($password, PASSWORD_DEFAULT);
        $sqlGetUserData = "UPDATE students SET firstName = '$firstName', lastName = '$lastName', username = '$username', password = '$password' WHERE studentId = '$studentId'";
        mysqli_query($conn, $sqlGetUserData);
        header("location: ../admin.php");
    }else{
        $sqlGetUserData = "UPDATE students SET firstName = '$firstName', lastName = '$lastName', username = '$username' WHERE studentId = '$studentId'";
        mysqli_query($conn, $sqlGetUserData);
        header("location: ../admin.php");
    }
    
}
?>