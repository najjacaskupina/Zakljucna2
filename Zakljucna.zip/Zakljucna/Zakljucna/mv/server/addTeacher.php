<?php
include 'conn.php';
session_start();
if (!isset($_SESSION['adminToken'])) {
  header("Location: ../index.php");
}
$token = $_SESSION['adminToken'];

$cypherMethod = 'AES-256-CBC';
$key = "markoVosner27";
$iv = '1234567891011121';

$firstName = $_POST['firstName'];
$lastName = $_POST['lastName'];
$username = $_POST['username'];
$password = $_POST['password'];

$firstName = mysqli_real_escape_string($conn, $firstName);
$lastName = mysqli_real_escape_string($conn, $lastName);
$username = mysqli_real_escape_string($conn, $username);
$password = mysqli_real_escape_string($conn, $password);

$sqlGetEmail = "select * from teachers where username = '$username'";
$resultGetEmail = mysqli_query($conn, $sqlGetEmail);
if(mysqli_num_rows($resultGetEmail)>=1){
    exit("User exists");
}else{
    $password = password_hash($password, PASSWORD_DEFAULT);
    $sqlInsertData = "insert into teachers (teacherFirstName, teacherLastName, username, password) values ('$firstName', '$lastName', '$username', '$password')";
    mysqli_query($conn, $sqlInsertData);
    header('Location: ../admin.php');
    }

?>