
<?php
include 'conn.php';
include 'adminSession.php';

$studentId = $_POST['rmStudent'];

$sqlValidateAdmin = "select * from admin where token = '$token'";
$resultValidateAdmin = mysqli_query($conn, $sqlValidateAdmin);
if(!mysqli_num_rows($resultValidateAdmin)>=1){
    exit("Wrong token");
}else{
    $sqlDeleteData = "DELETE FROM students WHERE studentId = '$studentId'";
    mysqli_query($conn, $sqlDeleteData);
    header("location: ../admin.php");
    
}
?>