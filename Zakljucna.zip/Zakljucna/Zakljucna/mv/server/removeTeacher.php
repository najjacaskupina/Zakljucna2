<?php
include 'conn.php';
include 'adminSession.php';

$teacherId = $_POST['rmTeacher'];

$sqlValidateAdmin = "select * from admin where token = '$token'";
$resultValidateAdmin = mysqli_query($conn, $sqlValidateAdmin);
if(!mysqli_num_rows($resultValidateAdmin)>=1){
    exit("Wrong token");
}else{
    $sqlDeleteData = "DELETE FROM teachers WHERE teacherId = '$teacherId'";
    mysqli_query($conn, $sqlDeleteData);
    header("location: ../admin.php");
    
}
?>