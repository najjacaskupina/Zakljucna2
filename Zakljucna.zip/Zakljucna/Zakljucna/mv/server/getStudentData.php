<?php
include 'conn.php';

$token = $_POST['token'];
$studentId = $_POST['studentId'];

$sqlValidateAdmin = "select * from admin where token = '$token'";
$resultValidateAdmin = mysqli_query($conn, $sqlValidateAdmin);
if(!mysqli_num_rows($resultValidateAdmin)>=1){
    exit("Wrong token");
}else{
    $sqlGetUserData = "select * from students where studentId = '$studentId'";
    $resultGetUserData = mysqli_query($conn, $sqlGetUserData);
    $rowGetUserData = mysqli_fetch_array($resultGetUserData);
    exit(json_encode($rowGetUserData));
}
?>