<?php
include 'conn.php';
session_start();
if (!isset($_SESSION['adminToken'])) {
  header("Location: index.php");
}
$token = $_SESSION['adminToken'];
/*
echo "token €tokenid = id uporabnika+čas v unix <br>";
echo "token trenutne seje: €token = openssl_encrypt(€tokenId, €cypherMethod, €key, €options=0, €iv); <br></blockquote>";
echo $token;
*/
?>