<?php
include 'conn.php';
include 'adminSession.php';

$subjectId = $_POST['subjectId'];

$subjectName = $_POST['subjectNameEdit'];
$abbr = $_POST['abbrEdit'];
$year = $_POST['yearEdit'];

$subjectName = mysqli_real_escape_string($conn, $subjectName);
$abbr = mysqli_real_escape_string($conn, $abbr);
$year = mysqli_real_escape_string($conn, $year);

$sqlValidateAdmin = "select * from admin where token = '$token'";
$resultValidateAdmin = mysqli_query($conn, $sqlValidateAdmin);
if(!mysqli_num_rows($resultValidateAdmin)>=1){
    exit("Wrong token");
}else{
        $sqlGetUserData = "UPDATE subjects SET subjectName = '$subjectName', abbr = '$abbr', year = '$year' WHERE subjectId = '$subjectId'";
        mysqli_query($conn, $sqlGetUserData);
        header("location: ../admin.php");
    
}
?>