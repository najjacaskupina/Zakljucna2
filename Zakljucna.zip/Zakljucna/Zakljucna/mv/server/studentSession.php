<?php
include 'conn.php';
session_start();
if (!isset($_SESSION['studentToken'])) {
  header("Location: index.php");
}
$studentToken = $_SESSION['studentToken'];
$sqlStudentsData = "select * from students where token = '$studentToken'";
$resultStudentsData = mysqli_query($conn, $sqlStudentsData);
$rowStudentsData = mysqli_fetch_array($resultStudentsData);
$studentId = $rowStudentsData['studentId'];
$username = $rowStudentsData['username'];
$firstName = $rowStudentsData['firstName'];
$lastName = $rowStudentsData['lastName'];
$dir = "tasks/".$studentId;
if(is_dir("server")){
    if(is_dir($dir) === false){
        mkdir($dir, 0777);
    }
}
/*
echo "token €tokenid = id uporabnika+čas v unix <br>";
echo "token trenutne seje: €token = openssl_encrypt(€tokenId, €cypherMethod, €key, €options=0, €iv); <br></blockquote>";
echo $token;
*/
?>