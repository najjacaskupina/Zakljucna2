<?php
include 'conn.php';
include 'adminSession.php';

$teacherId = $_POST['teacherId'];

$firstName = $_POST['teacherFirstNameEdit'];
$lastName = $_POST['teacherLastNameEdit'];
$username = $_POST['teacherUsernameEdit'];
$password = $_POST['teacherPasswordEdit'];

$firstName = mysqli_real_escape_string($conn, $firstName);
$lastName = mysqli_real_escape_string($conn, $lastName);
$username = mysqli_real_escape_string($conn, $username);
$password = mysqli_real_escape_string($conn, $password);

$sqlValidateAdmin = "select * from admin where token = '$token'";
$resultValidateAdmin = mysqli_query($conn, $sqlValidateAdmin);
if(!mysqli_num_rows($resultValidateAdmin)>=1){
    exit("Wrong token");
}else{
    if($password != ""){
        $password = password_hash($password, PASSWORD_DEFAULT);
        $sqlGetUserData = "UPDATE teachers SET teacherFirstName = '$firstName', teacherLastName = '$lastName', username = '$username', password = '$password' WHERE teacherId = '$teacherId'";
        mysqli_query($conn, $sqlGetUserData);
        header("location: ../admin.php");
    }else{
        $sqlGetUserData = "UPDATE teachers SET teacherFirstName = '$firstName', teacherLastName = '$lastName', username = '$username' WHERE teacherId = '$teacherId'";
        mysqli_query($conn, $sqlGetUserData);
        header("location: ../admin.php");
    }
    
}
?>