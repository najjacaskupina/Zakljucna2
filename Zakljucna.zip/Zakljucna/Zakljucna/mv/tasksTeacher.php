<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tasks ~ Teacher</title>
    <link rel="icon" type="image/x-icon" href="/media/logo.png">
    <link rel="stylesheet" href="styles/tasksTeacher.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter" rel="stylesheet">
    <script>
        function showSubmissions(val){
            x = document.getElementById('submissions');
            x.style.display = "block";
            str = '<span class="x" onclick="hideSubmissions()">x</span>';
            str += "<table><tr> <th>Name of student</th> <th>Date</th> <th>Task</th> </tr><tr> <td>Teo</td> <td>11.11.1111</td> <td>Task</td> </tr><tr> <td>Teo</td> <td>11.11.1111</td> <td>Task</td> </tr></table>";
            x.innerHTML = str;
        }
        function hideSubmissions(){
            x = document.getElementById('submissions');
            x.style.display = "none";
            x.innerHTML = "";
        }
    </script>
</head>
<body>
    <div id="submissions">
        <span class="x" onclick="hideSubmissions()">x</span>
    </div>
    <div class="container">
        <aside>
            <div class="heading">
                <h3>Octopussy classroom</h3>
            </div>
            <div class="middleSidebar">
                <ul>
                    <li onclick="window.location='homeTeacher.php'">
                        <span>My Profile</span>
                        <img class="sidebar-icon" src="media/profile.png" alt="profile">
                    </li>
                    <li class="active" onclick="window.location='tasksTeacher.php'">
                        <span>Tasks</span>
                        <img class="sidebar-icon" src="media/tasks.png" alt="profile">
                    </li>
                    <li onclick="window.location='gradesTeacher.php'">
                        <span>Grades</span>
                        <img class="sidebar-icon" src="media/grades.png" alt="profile">
                    </li>
                    <li onclick="window.location='server/logoutTeacher.php'">
                        <span>Log out</span>
                        <img class="sidebar-icon" src="media/logout.png" alt="profile">
                    </li>
                </ul>
            </div>
        </aside>
        <main>
            <h1>My tasks</h1>
            <h2>Slovenščina</h2>
            <table>
                <tbody>
                    <tr>
                        <th>Task</th>
                        <th>Date added</th>
                        <th>Date finished</th>
                        <th>Submissions</th>
                    </tr>
                    <tr>
                        <td>Task1</td>
                        <td>1.1.1111</td>
                        <td>1.1.1111</td>
                        <td onclick="showSubmissions(1)">10</td>
                    </tr>
                    <tr>
                        <td>Task1</td>
                        <td>1.1.1111</td>
                        <td>1.1.1111</td>
                        <td onclick="showSubmissions(1)">10</td>
                    </tr>
                    <tr>
                        <td>Task1</td>
                        <td>1.1.1111</td>
                        <td>1.1.1111</td>
                        <td onclick="showSubmissions(1)">10</td>
                    </tr>
                 </tbody>
            </table>
            <form action="" method="post">
                <input type="text" name="name" placeholder="Name of task">
                <input type="file" name="file">
                <label for="dateFinished">Date finished:</label>
                <input type="date" name="dateFinished">
                <input type="submit" value="Add task">
            </form>
            <h2>Matematika</h2>
            <table>
                <tbody>
                    <tr>
                        <th>Task</th>
                        <th>Date added</th>
                        <th>Date finished</th>
                        <th>Submissions</th>
                    </tr>
                    <tr>
                        <td>Task1</td>
                        <td>1.1.1111</td>
                        <td>1.1.1111</td>
                        <td onclick="showSubmissions(1)">10</td>
                    </tr>
                    <tr>
                        <td>Task1</td>
                        <td>1.1.1111</td>
                        <td>1.1.1111</td>
                        <td onclick="showSubmissions(1)">10</td>
                    </tr>
                    <tr>
                        <td>Task1</td>
                        <td>1.1.1111</td>
                        <td>1.1.1111</td>
                        <td onclick="showSubmissions(1)">10</td>
                    </tr>
                 </tbody>
            </table>
            <form action="" method="post">
                <input type="text" name="name" placeholder="Name of task">
                <input type="file" name="file">
                <label for="dateFinished">Date finished:</label>
                <input type="date" name="dateFinished">
                <input type="submit" value="Add task">
            </form>
        </main>
    </div>
    <footer>
        <img src="media/logo.png" alt="logo">
        <p>Marko Vošner &copy; | 2022</p>
    </footer>
</body>
</html>