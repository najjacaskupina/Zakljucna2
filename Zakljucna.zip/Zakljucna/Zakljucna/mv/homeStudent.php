<?php
include 'server/studentSession.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home ~ Student</title>
    <link rel="icon" type="image/x-icon" href="media/logo.png">
    <link rel="stylesheet" href="styles/homeStudent.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter" rel="stylesheet">
    <link rel="stylesheet" href="https://unpkg.com/aos@next/dist/aos.css" />
</head>
<body>
    <div class="container">
        <aside data-aos="fade-right">
            <div class="heading">
                <h3>Octopussy classroom</h3>
            </div>
            <div class="middleSidebar">
                <ul>
                    <li class="active" onclick="window.location='homeStudent.php'">
                        <span>My Profile</span>
                        <img class="sidebar-icon" src="media/profile.png" alt="profile">
                    </li>
                    <li onclick="window.location='subjectsStudent.php'">
                        <span>Subjects</span>
                        <img class="sidebar-icon" src="media/subjects.png" alt="profile">
                    </li>
                    <li onclick="window.location='tasksStudent.php'">
                        <span>Tasks</span>
                        <img class="sidebar-icon" src="media/tasks.png" alt="profile">
                    </li>
                    <li onclick="window.location='gradesStudent.php'">
                        <span>Grades</span>
                        <img class="sidebar-icon" src="media/grades.png" alt="profile">
                    </li>
                    <li onclick="window.location='server/logout.php'">
                        <span>Log out</span>
                        <img class="sidebar-icon" src="media/logout.png" alt="profile">
                    </li>
                </ul>
            </div>
        </aside>
        <main>
            <section data-aos="fade-in" data-aos-delay="900">
                <h1>My profile</h1>
                <img src="media/profile.png" alt="profile">
                <div class="data">
                    <span><b>First Name:</b> <?php echo $firstName; ?></span>
                    <span><b>Last Name:</b> <?php echo $lastName; ?></span>
                    <span><b>Full Name:</b> <?php echo $firstName . " " . $lastName; ?></span>
                    <span><b>Username:</b> <?php echo $username; ?></span>
                    <button>Change Your Profile</button>
                </div>
            </section>
            <section class="subjects" data-aos="fade-up" data-aos-delay="1200">
                <h2>My subjects</h2>
                <div class="container" data-aos="fade-up" data-aos-delay="200">
                    <?php
                    $sqlCheckUserSubjects = "select * from viewstudentsinsubjects where token = '$studentToken'";
                    $resultCheckUserSubjects = mysqli_query($conn, $sqlCheckUserSubjects);
                    $rowCheckUserSubjects = mysqli_fetch_array($resultCheckUserSubjects);
                    if($rowCheckUserSubjects == null){
                        echo "<a href='vsiPredmeti.php'>You are not enrolled in any subject</a>";
                    }else{
                        $sqlGetUserSubjects = "select * from viewstudentsinsubjects where token = '$studentToken'";
                        $resultGetUserSubjects = mysqli_query($conn, $sqlGetUserSubjects);
                        while($rowGetUserSubjects = mysqli_fetch_array($resultGetUserSubjects)){
                        $abbr = strtolower($rowGetUserSubjects['abbr']);
                        $subjectName = $rowGetUserSubjects['subjectName'];
                        $subjectId = $rowGetUserSubjects['subjectId'];
                        $year = $rowGetUserSubjects['year'];
                        include 'parts/subjectBoxStudent.php';
                        }
                    }
                    ?>
                </div>
            </section>
            <section class="tasks" data-aos="fade-up">
                <h2>Latest tasks</h2>
                <table>
                    <tbody>
                        <tr>
                            <th>Task</th>
                            <th>Date added</th>
                            <th>Subject</th>
                            <th>Submit</th>
                        </tr>
                        <?php
                        /* CREATE VIEW viewalltasksfromstudent AS
                            SELECT tasks.*, subjects.subjectName, students.studentId, students.token FROM tasks
                            INNER JOIN subjects ON tasks.subjectId = subjects.subjectId
                            INNER JOIN students_subjects on subjects.subjectId = students_subjects.subjectId
                            INNER JOIN students on students_subjects.studentId = students.studentId 
                        */
                        $sqlCheckUserTasks = "select * from viewalltasksfromstudent where token = '$studentToken'";
                        $resultCheckUserTasks = mysqli_query($conn, $sqlCheckUserTasks);
                        $rowCheckUserTasks = mysqli_fetch_array($resultCheckUserTasks);
                        if($rowCheckUserTasks == null){
                            echo "<tr> <td><a href=''>You dont have any tasks</a></td></tr>";
                        }else{
                            $sqlGetUserTasks = "select * from viewalltasksfromstudent where token = '$studentToken' order by taskStartDate limit 5";
                            $resultGetUserTasks = mysqli_query($conn, $sqlGetUserTasks);
                            while($rowGetUserTasks = mysqli_fetch_array($resultGetUserTasks)){
                            $taskName = $rowGetUserTasks['taskName'];
                            $subjectName = $rowGetUserTasks['subjectName'];
                            $taskEndDate = $rowGetUserTasks['taskEndDate'];
                            $year = $rowGetUserTasks['year'];
                            echo '<tr> <td>'.$taskName.'</td> <td>'.$taskEndDate.'</td> <td>'.$subjectName." ".$year.'</td> <td> <form action="post" method="post"> <input type="file" name="" id=""> <input type="submit" value="Submit task"> </form> </td> </tr>';
                            }
                        }
                        ?>
                     </tbody>
                </table>
            </section>
        </main>
    </div>
    <?php 
        include 'parts/footer.html';
        include 'aos/aosSetting.html';
    ?>
</body>
</html>