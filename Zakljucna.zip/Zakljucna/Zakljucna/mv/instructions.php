<?php
//vedno imoortaš conn.php, glej, v kateri mapi si. Če si v glavni mapi importas include 'server/conn.php', če si v server z 'conn.php'
include 'server/conn.php';

//v to $spremenljivko napišeš sql stavek, ki želiš da se izvede v bazi
$sqlReadData = "select * from students";
// izvedeš sql in ga shraniš v $spremenljivko
$resultReadData = mysqli_query($conn, $sqlReadData);
// če je select stavek podatke izpišeš s tem, če ni ignoriraj ta step
while ($rowreadData = mysqli_fetch_array($resultReadData)) {
    //echo izpisuje html obliko
    // $spremenljivka v while 
    // stolpec izpišeš z $spremenljivka['imeStolpca']
    //echo $rowreadData['firstName'];
    // lahko tudi kombiniraš s html tagi in classi, html mora vedno biti v "", spremenljivke pa ne. združiš z "tag".$spremenljivka."tag"
    // pazi da ti " ne prekine, če želiš izpisati <p class="mojClass">, to ne bo delovalo. V notranjih " pred vsakim " uporabljaj \ -> <p class\"mojClass\">
    echo "<h1 class=\"mojClass\">".$rowreadData['firstName']."</h1>";
}

/*
to do:
    -vse za učitelja,
    -oddaja datotek za učenca in učitelja pri nalogah,
    -učitelj naloge oddaja v svojo mapo, do katere je pot definirana v tabeli tasks in stolpcu pathToFile,
    -naredi datoteke downloadable (dodaj download v -> <a href="" download>),
    -naredi tabelo oddane naloge{
        int auto increment PK submittedTaskId,
        int studentId,
        int taskId,
        varchar 100 znakov pathToFile
        timestamp timeSubmitted
    }
    --ko učenec odda nalogo skozi formo v studentTasks ali subjectStudent poglej actiond="pot" in naredi datoteko.php kot piše v action
    -ne pozabi importati conn.php v vsako php datoteko, ki komunicira z bazo!!!
    -naredi opcijo urejanja profila

    ------------
    --OPTIONAL--
    ------------
    -profilna slika vsakega uporabnika

    ------------
    ----Done----
    ------------
    -admin je v celoti narejen in vse glede učenca razen oddajanja nalog in nastavitve profila (change profile v studentHome.php)
    -geslo za admina je admin
    -samo v adminu lahko dodaš učitelje in predmete, ker ne sme biti možnosti odprte registracije za njih


*/


?>