<?php

include 'server/teacherSession.php';
$subjectId = $_GET['subjectId'];

$sql = "select * from teachers, teachers_subjects where teachers_subjects.subjectId = '$subjectId' and teachers.teacherId = teachers_subjects.teacherId";
$result = mysqli_query($conn, $sql);
$row = mysqli_fetch_array($result);


?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mat ~ Teacher</title>
    <link rel="icon" type="image/x-icon" href="/media/logo.png">
    <link rel="stylesheet" href="styles/subjectStudent.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter" rel="stylesheet">
    <link rel="stylesheet" href="https://unpkg.com/aos@next/dist/aos.css" />
    <script>
        function showSubmissions(val){
            x = document.getElementById('submissions');
            x.style.display = "block";
            str = '<span class="x" onclick="hideSubmissions()">x</span>';
            str += "<table><tr> <th>Name of student</th> <th>Date</th> <th>Task</th> </tr><tr> <td>Teo</td> <td>11.11.1111</td> <td>Task</td> </tr><tr> <td>Teo</td> <td>11.11.1111</td> <td>Task</td> </tr></table>";
            x.innerHTML = str;
        }
        function hideSubmissions(){
            x = document.getElementById('submissions');
            x.style.display = "none";
            x.innerHTML = "";
        }
    </script>
</head>
<body>
    <div id="submissions">
        <span class="x" onclick="hideSubmissions()">x</span>
    </div>
    <div class="container">
        <aside data-aos="fade-right">
            <div class="heading">
                <h3>Octopussy classroom</h3>
            </div>
            <div class="middleSidebar">
                <ul>
                    <li class="active" onclick="window.location='homeTeacher.php'">
                        <span>My Profile</span>
                        <img class="sidebar-icon" src="media/profile.png" alt="profile">
                    </li>
                    <li onclick="window.location='tasksTeacher.php'">
                        <span>Tasks</span>
                        <img class="sidebar-icon" src="media/tasks.png" alt="profile">
                    </li>
                    <li onclick="window.location='gradesTeacher.php'">
                        <span>Grades</span>
                        <img class="sidebar-icon" src="media/grades.png" alt="profile">
                    </li>
                    <li onclick="window.location='server/logoutTeacher.php'">
                        <span>Log out</span>
                        <img class="sidebar-icon" src="media/logout.png" alt="profile">
                    </li>
                </ul>
            </div>
        </aside>
        <main>
            <section data-aos="fade-in" data-aos-delay="900">
                <h1></h1>
                <img src="media/profile.png" alt="profile">
                <div class="data">
                    <span><b>Teacher:</b><?php echo $row['teacherFirstName']." ".$row['teacherLastName'] ?></span>
                    <span><b>All tasks:</b> </span>
                    <span><b>Done tasks:</b> </span>
                    <span><b>Avg. grade:</b> </span>
                    <button onclick="window.location='server/enroll.php'">Enroll</button>
                </div>
            </section>
            <section class="tasks" data-aos="fade-up">
                <h2>Tasks</h2>
                <table>
                    <tbody>
                        <tr>
                            <th>Task</th>
                            <th>Date added</th>
                            <th>Date finished</th>
                            <th>Submissions</th>
                        </tr>
                        <?php
                        $sqlGetTasks = "SELECT * FROM tasks WHERE subjectId = '$subjectId';";
                        $resultGetTasks = mysqli_query($conn, $sqlGetTasks);
                        while ($rowGetTasks = mysqli_fetch_array($resultGetTasks)) {
                            echo "<tr> <td>".$rowGetTasks['taskName']."</td> <td>".$rowGetTasks['taskStartDate']."</td> <td>".$rowGetTasks['taskEndDate']."</td> <td onclick=\"showSubmissions(".$rowGetTasks['taskId'].")\">10</td> </tr>";
                        }
                        ?>
                     </tbody>
                </table>
                <form action="server/addTask.php" method="post" enctype="multipart/form-data">
                    <input type="text" name="name" placeholder="Name of task">
                    <input type="file" name="file">
                    <label for="dateFinished">Date finished:</label>
                    <input type="date" name="dateFinished">
                    <input type="hidden" name="subjectId" value="<?php echo $subjectId;?>">
                    <input type="submit" value="Add task">
                    
                </form>
            </section>
            <section class="grades" data-aos="fade-up">
                <h2>Grades</h2>
                <table>
                    <tbody>
                        <tr>
                            <th>Student name</th>
                            <th>Grades</th>
                            <th>Final grade</th>
                            <th>last changed</th>
                            <th>Add</th>
                        </tr>
                       
                        <?php
                        $sqlGetStudentsInSubjects = "SELECT * FROM viewstudentsinsubjects WHERE subjectId = '$subjectId';";
                        $resultGetStudentsInSubjects = mysqli_query($conn, $sqlGetStudentsInSubjects);
                        while ($rowGetStudentsInSubjects = mysqli_fetch_array($resultGetStudentsInSubjects)) {
                        $studentId = $rowGetStudentsInSubjects['studentId'];
                        echo "<tr> <td>".$rowGetStudentsInSubjects['firstName']." ".$rowGetStudentsInSubjects['lastName']."</td> <td>";
                        $sqlGetGrades = "SELECT * FROM grades WHERE subjectId = '$subjectId' AND studentId = '$studentId';";
                        $resultGetGrades = mysqli_query($conn, $sqlGetGrades);
                        while ($rowGetGrades = mysqli_fetch_array($resultGetGrades)) {
                            echo $rowGetGrades['grade']." ";
                        }
                        echo "</td> <td>4</td> <td>11.1.1111</td> <td> <form action=\"server/addGrade.php\" method=\"post\"> <input type=\"number\" name=\"grade\" min=\"1\" max=\"5\"> <label for=\"final\">Final grade:</label><input type=\"checkbox\" name=\"final\"> <input type=\"hidden\" name=\"studentId\" value=\"".$studentId."\"> <input type=\"hidden\" name=\"subjectId\" value=\"".$subjectId."\"> <input type=\"submit\" value=\"Add grade\"> </form> </td> </tr>";
                        }
                        ?>
                     </tbody>
                </table>
            </section>
        </main>
    </div>
    <footer data-aos="fade-up" data-aos-delay="0" data-aos-duration="1200">
        <img src="media/logo.png" alt="logo">
        <p>Marko Vošner &copy; | 2022</p>
    </footer>
    <script src="https://unpkg.com/aos@next/dist/aos.js"></script>
    <script>
        AOS.init({
      // Global settings:
      disable: false, // accepts following values: 'phone', 'tablet', 'mobile', boolean, expression or function
      startEvent: 'DOMContentLoaded', // name of the event dispatched on the document, that AOS should initialize on
      initClassName: 'aos-init', // class applied after initialization
      animatedClassName: 'aos-animate', // class applied on animation
      useClassNames: false, // if true, will add content of `data-aos` as classes on scroll
      disableMutationObserver: false, // disables automatic mutations' detections (advanced)
      debounceDelay: 50, // the delay on debounce used while resizing window (advanced)
      throttleDelay: 99, // the delay on throttle used while scrolling the page (advanced)
      
    
      // Settings that can be overridden on per-element basis, by `data-aos-*` attributes:
      offset: 120, // offset (in px) from the original trigger point
      delay: 200, // values from 0 to 3000, with step 50ms
      duration: 1500, // values from 0 to 3000, with step 50ms
      easing: 'ease', // default easing for AOS animations
      once: false, // whether animation should happen only once - while scrolling down
      mirror: false, // whether elements should animate out while scrolling past them
      anchorPlacement: 'top-bottom', // defines which position of the element regarding to window should trigger the animation
    
    });
      </script>
</body>
</html>