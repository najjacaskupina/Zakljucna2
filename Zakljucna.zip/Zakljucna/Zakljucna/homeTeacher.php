<?php
include 'server/teacherSession.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home ~ Teacher</title>
    <link rel="icon" type="image/x-icon" href="/media/logo.png">
    <link rel="stylesheet" href="styles/homeTeacher.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter" rel="stylesheet">
</head>
<body>
    <div class="container">
        <aside>
            <div class="heading">
                <h3>Web classroom</h3>
            </div>
            <div class="middleSidebar">
                <ul>
                    <li class="active" onclick="window.location='homeTeacher.php'">
                        <span>My Profile</span>
                        <img class="sidebar-icon" src="media/profile.png" alt="profile">
                    </li>
                    <li onclick="window.location='tasksTeacher.php'">
                        <span>Tasks</span>
                        <img class="sidebar-icon" src="media/tasks.png" alt="profile">
                    </li>
                    <li onclick="window.location='gradesTeacher.php'">
                        <span>Grades</span>
                        <img class="sidebar-icon" src="media/grades.png" alt="profile">
                    </li>
                    <li onclick="window.location='server/logoutTeacher.php'">
                        <span>Log out</span>
                        <img class="sidebar-icon" src="media/logout.png" alt="profile">
                    </li>
                </ul>
            </div>
        </aside>
        <main>
            <section>
                <h1>My profile</h1>
                <img src="media/profile.png" alt="profile">
                <div class="data">
                <span><b>First Name:</b> <?php echo $firstName; ?></span>
                    <span><b>Last Name:</b> <?php echo $lastName; ?></span>
                    <span><b>Full Name:</b> <?php echo $firstName . " " . $lastName; ?></span>
                    <span><b>Username:</b> <?php echo $username; ?></span>
                    <button>Change Your Profile</button>
                </div>
            </section>
            <section class="subjects">
                <h2>My subjects</h2>
                <div class="container">
                <?php
                    $sqlCheckUserSubjects = "select * from viewteachersinsubjects where token = '$teacherToken'";
                    $resultCheckUserSubjects = mysqli_query($conn, $sqlCheckUserSubjects);
                    $rowCheckUserSubjects = mysqli_fetch_array($resultCheckUserSubjects);
                    if($rowCheckUserSubjects == null){
                        echo "<a href='vsiPredmeti.php'>You are not enrolled in any subject</a>";
                    }else{
                        $sqlGetUserSubjects = "select * from viewteachersinsubjects where token = '$teacherToken'";
                        $resultGetUserSubjects = mysqli_query($conn, $sqlGetUserSubjects);
                        while($rowGetUserSubjects = mysqli_fetch_array($resultGetUserSubjects)){
                        $abbr = strtolower($rowGetUserSubjects['abbr']);
                        $subjectName = $rowGetUserSubjects['subjectName'];
                        $subjectId = $rowGetUserSubjects['subjectId'];
                        $year = $rowGetUserSubjects['year'];
                        include 'parts/subjectBox.php';
                        }
                    }
                    ?>
                </div>
            </section>
        </main>
    </div>
    <footer>
    <h2>About school</h2>
    <p>The School Center Celje is a Slovenian public education institution based in The Pot na Lavo 22 in Celje. It combines grammar schools, four secondary vocational schools, a higher vocational school and an inter-entrepreneurial education centre. It is one of the largest school centres in Slovenia. &copy; | 2022</p>
    </footer>
</body>
</html>